// const express = require('express');
// const cors = require('cors');
// const dotenv = require('dotenv');
// const db = require('./config/db');
// const userRoutes = require('./routes/userRoutes');
// const gameRoutes = require('./routes/gameRoutes');

// dotenv.config();

// const app = express();
// app.use(cors());
// app.use(express.json());

// // Routes
// app.use('/api/users', userRoutes);
// app.use('/api/games', gameRoutes);

// module.exports = app;


const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const db = require('./config/db');
const userRoutes = require('./routes/userRoutes');
const gameRoutes = require('./routes/gameRoutes');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // For parsing JSON request bodies

// Routes
app.use('/api/users', userRoutes);
app.use('/api/games', gameRoutes);

// Error handling for unknown routes
app.use((req, res) => {
  res.status(404).json({ msg: 'Route not found' });
});

module.exports = app;