const Game = require('../models/game');

// Controller to get all games by the logged-in user
exports.getGamesByUser = (req, res) => {
  const userId = req.userId; // Extracted from JWT token by auth middleware
  
  Game.findByUserId(userId, (err, results) => {
    if (err) {
      return res.status(500).json({ msg: 'Database error occurred while fetching games' });
    }
    if (results.length === 0) {
      return res.status(404).json({ msg: 'No games found for this user' });
    }
    res.status(200).json(results);
  });
};

exports.addGame = (req, res) => {
  const { title, genre, description } = req.body;
  const userId = req.userId; 

  if (!title || !genre) {
    return res.status(400).json({ msg: 'Title and genre are required' });
  }

  const newGame = {
    title,
    genre,
    description: description || '', 
  };

  Game.create(newGame, userId, (err, result) => {
    if (err) {
      return res.status(500).json({ msg: 'Database error occurred while adding the game' });
    }
    res.status(201).json({ msg: 'Game successfully added' });
  });
};
