const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

exports.register = (req, res) => {
  const { username, email, password } = req.body;

  bcrypt.hash(password, 10, (err, hash) => {
    if (err) throw err;
    const newUser = { username, email, password: hash };
    User.create(newUser, (err, result) => {
      if (err) return res.status(500).json({ msg: 'Database error' });
      res.status(201).json({ msg: 'User created' });
    });
  });
};

exports.login = (req, res) => {
  const { username, password } = req.body;

  User.findByUsername(username, (err, results) => {
    if (err) return res.status(500).json({ msg: 'Database error' });
    if (results.length === 0) return res.status(401).json({ msg: 'User not found' });

    const user = results[0];
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) throw err;
      if (!isMatch) return res.status(401).json({ msg: 'Invalid credentials' });

      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
      res.status(200).json({ token });
    });
  });
};

exports.profile = (req, res) => {
  const userId = req.userId;
  User.findById(userId, (err, result) => {
    if (err) return res.status(500).json({ msg: 'Database error' });
    res.json(result[0]);
  });
};
 