const express = require('express');
const { getGamesByUser, addGame } = require('../controllers/gameController');
const { authenticateJWT } = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/', authenticateJWT, getGamesByUser);

router.post('/', authenticateJWT, addGame);

module.exports = router;
