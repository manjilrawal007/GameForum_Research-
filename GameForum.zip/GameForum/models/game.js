const db = require('../config/db');

const Game = {};

Game.findByUserId = (userId, callback) => {
  const sql = 'SELECT * FROM games WHERE user_id = ?';
  db.query(sql, [userId], callback);
};

Game.create = (game, userId, callback) => {
  const sql = 'INSERT INTO games (title, genre, description, user_id) VALUES (?, ?, ?, ?)';
  db.query(sql, [game.title, game.genre, game.description, userId], callback);
};

module.exports = Game;
